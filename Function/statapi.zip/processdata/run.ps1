using module DataFunctions
# Input bindings are passed in via param block.
param($Request, $TriggerMetadata)

Write-Host $Request.Body.action

$body = $Request.Body
$action = $body.action

If(-not $action){
    $return = [Return]::new([PSCustomObject]@{
        Error = "Invalid input, either JSON is invalid, content-type header is missing, or no action property found in body."
    }, 400) 
}

If (-Not $return){
    try {
        Switch ($action){
            "sortObjectArray" {$return = Format-ObjectOrder -Body $body}
            "returnHighestItem" {$return = Format-ReturnHighest -Body $body}
            "processSentinelData" {$return = Format-SentinelData -Body $body}
            "changePropertyCase" {$return = Format-ChangeCase -Body $body}
            default {
                $return = [Return]::new([PSCustomObject]@{
                    Error = "Invalid action supplied in body."
                }, 400)
            }
        }
    }
    catch {
        $return = [Return]::new([PSCustomObject]@{
            Error = "An unexpected error has occurred."
        }, 400)
    }
}

# Associate values to output bindings by calling 'Push-OutputBinding'.
Push-OutputBinding -Name Response -Value ([HttpResponseContext]@{
    StatusCode = $return.status
    Body = $return.body
})
