    using module DataFunctions
# Input bindings are passed in via param block.
param($Request, $TriggerMetadata)

try{
    $body = $Request.Body | ConvertFrom-Json
    $action = $body.action
}
catch{
    $return = [Return]::new([PSCustomObject]@{
        Error = "Invalid input, the JSON body is invalid."
    }, 400)
}

If(-not $action -and -not $return){
    $return = [Return]::new([PSCustomObject]@{
        Error = "Invalid input, no action in JSON body."
    }, 400) 
}

If (-Not $return){
    try {
        Switch ($action){
            "sortObjectArray" {$return = Format-ObjectOrder -Body $body}
            "returnHighestItem" {$return = Format-ReturnHighest -Body $body}
            "processSentinelData" {$return = Format-SentinelData -Body $body}
            "changePropertyCase" {$return = Format-ChangeCase -Body $body}
            default {
                $return = [Return]::new([PSCustomObject]@{
                    Error = "Invalid action supplied in body."
                }, 400)
            }
        }
    }
    catch {
        $return = [Return]::new([PSCustomObject]@{
            Error = "An unexpected error has occurred."
        }, 400)
    }
}

# Associate values to output bindings by calling 'Push-OutputBinding'.
Push-OutputBinding -Name Response -Value ([HttpResponseContext]@{
    StatusCode = $return.status
    Body = $return.body
})
