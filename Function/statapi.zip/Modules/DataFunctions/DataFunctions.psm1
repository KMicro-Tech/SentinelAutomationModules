class Return {
    [object]$body
    [int]$status

    Return(
        [object]$o
    ){
        $this.body = $o
        $this.status = 200
    }
    Return(
        [object]$o,
        [int]$i
    ){
        $this.body = $o
        $this.status = $i
    }
}
function Format-ObjectOrder {
    param(
        [PSObject]$body
    )

    If ($body.sortorder -eq 'desc'){
        $sorted = $body.data | Sort-Object -Property $body.sortkeys -Descending

    }else{
        $sorted = $body.data | Sort-Object -Property $body.sortkeys
    }

    return [Return]::new($sorted)
}

function Format-ReturnHighest {
    param(
        [PSObject]$body
    )

    $orderedList = $body.orderedList ?? ('High','Medium','Low','Informational','Unknown')
    $data = $body.data

    foreach ($item in $orderedList){
        if($data -contains $item){
            $out = $item
            break
        }
    }

    return [Return]::new($out ?? 'Unknown')
}

function Format-SentinelData {
    param(
        [PSObject]$body
    )

    $columns = $body.data.tables[0].columns
    $rows = $body.data.tables[0].rows
    $results = @()

    foreach ($row in $rows){
        $obj = [PSCustomObject]@{}
        $count = 0
        foreach ($column in $columns){
            $obj | Add-Member -MemberType NoteProperty -Name $column.name -Value $row[$count]
            $count++
        }
        $results += $obj
        
    }

    return [Return]::new($results)
}

function Format-ChangeCase {
    param(
        [PSObject]$body
    )

    $data = $body.data
    $properties = $body.properties
    $case = $body.case

    foreach ($prop in $properties){
        Switch ($case){
            "upper" {
                $data.$prop = $data.$prop.ToUpper()
            }
            "lower" {
                $data.$prop = $data.$prop.ToLower()
            }
            "title" {
                $data.$prop = (Get-Culture).TextInfo.ToTitleCase($data.$prop)
            }
        }
    }

    return [Return]::new($data)
}